import React, { useState } from 'react';
import { Box, Button, VStack, Text, Input, HStack, useToast, Flex, Icon } from '@chakra-ui/react';
import { FaHandPointUp, FaArrowsAltV, FaArrowsAltH, FaUser } from 'react-icons/fa';
import './EditorTapestry.css';

function Editor() {
  const [step, setStep] = useState(1); // Controla los pasos del flujo
  const [stitchType, setStitchType] = useState(''); // Tipo de punto
  const [orientation, setOrientation] = useState(''); // Orientación
  const [handedness, setHandedness] = useState(''); // Diestro o zurdo
  const [dimensions, setDimensions] = useState({ width: '', height: '' }); // Dimensiones

  const toast = useToast();

  const handleNextStep = () => {
    if (step === 1 && !stitchType) {
      toast({
        title: 'Selecciona un tipo de punto.',
        status: 'warning',
        duration: 3000,
        isClosable: true,
      });
      return;
    }

    if (step === 2 && !orientation) {
      toast({
        title: 'Selecciona la orientación.',
        status: 'warning',
        duration: 3000,
        isClosable: true,
      });
      return;
    }

    if (step === 3 && !handedness) {
      toast({
        title: 'Indica si eres diestro o zurdo.',
        status: 'warning',
        duration: 3000,
        isClosable: true,
      });
      return;
    }

    if (step === 4 && (!dimensions.width || !dimensions.height)) {
      toast({
        title: 'Indica las dimensiones de la grilla.',
        status: 'warning',
        duration: 3000,
        isClosable: true,
      });
      return;
    }

    setStep((prev) => prev + 1);
  };

  return (
    <Box className="editor-container">
      {step === 1 && (
        <VStack spacing={6} className="editor-step">
          <Text className="editor-title">¿Qué tipo de punto deseas usar?</Text>
          <HStack spacing={4} className="editor-options">
            <Button
              leftIcon={<Icon as={FaHandPointUp} />}
              className={`editor-button ${stitchType === 'puntoBajo' ? 'selected' : ''}`}
              onClick={() => setStitchType('puntoBajo')}
            >
              Punto Bajo
            </Button>
            <Button
              leftIcon={<Icon as={FaHandPointUp} />}
              className={`editor-button ${stitchType === 'puntoAlto' ? 'selected' : ''}`}
              onClick={() => setStitchType('puntoAlto')}
            >
              Punto Alto
            </Button>
          </HStack>
        </VStack>
      )}

      {step === 2 && (
        <VStack spacing={6} className="editor-step">
          <Text className="editor-title">Selecciona la orientación</Text>
          <HStack spacing={4} className="editor-options">
            <Button
              leftIcon={<Icon as={FaArrowsAltV} />}
              className={`editor-button ${orientation === 'vertical' ? 'selected' : ''}`}
              onClick={() => setOrientation('vertical')}
            >
              Vertical
            </Button>
            <Button
              leftIcon={<Icon as={FaArrowsAltH} />}
              className={`editor-button ${orientation === 'horizontal' ? 'selected' : ''}`}
              onClick={() => setOrientation('horizontal')}
            >
              Horizontal
            </Button>
          </HStack>
        </VStack>
      )}

      {step === 3 && (
        <VStack spacing={6} className="editor-step">
          <Text className="editor-title">¿Sos diestro/a o zurdo/a?</Text>
          <HStack spacing={4} className="editor-options">
            <Button
              leftIcon={<Icon as={FaUser} />}
              className={`editor-button ${handedness === 'diestro' ? 'selected' : ''}`}
              onClick={() => setHandedness('diestro')}
            >
              Diestro
            </Button>
            <Button
              leftIcon={<Icon as={FaUser} />}
              className={`editor-button ${handedness === 'zurdo' ? 'selected' : ''}`}
              onClick={() => setHandedness('zurdo')}
            >
              Zurdo
            </Button>
          </HStack>
        </VStack>
      )}

      {step === 4 && (
        <VStack spacing={6} className="editor-step">
          <Text className="editor-title">Indica la cantidad de puntos y vueltas para tu grilla</Text>
          <HStack spacing={4} className="editor-dimensions">
            <Input
              className="editor-input"
              placeholder="Puntos (X)"
              value={dimensions.width}
              onChange={(e) => setDimensions({ ...dimensions, width: e.target.value })}
              type="number"
            />
            <Input
              className="editor-input"
              placeholder="Vueltas (Y)"
              value={dimensions.height}
              onChange={(e) => setDimensions({ ...dimensions, height: e.target.value })}
              type="number"
            />
          </HStack>
        </VStack>
      )}

      {step === 5 && (
        <Box className="editor-step">
          <Text className="editor-title">¡Tu grilla está lista!</Text>
          {/* Aquí se puede insertar el componente de la grilla */}
        </Box>
      )}

      <Flex mt={8} justifyContent="center" className="editor-navigation">
        <HStack spacing={4}>
          <Button
            className="editor-nav-button"
            onClick={() => setStep((prev) => Math.max(1, prev - 1))}
            isDisabled={step === 1}
          >
            Anterior
          </Button>
          <Button className="editor-nav-button" onClick={handleNextStep}>
            {step < 5 ? 'Siguiente' : 'Comenzar Diseño'}
          </Button>
        </HStack>
      </Flex>
    </Box>
  );
}

export default Editor;
